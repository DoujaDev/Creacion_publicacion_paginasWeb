//Varable globales
var elegidas=[];       //array donde guardo la mezcla de las cartas
var Cartasvueltas=0;  //numero de cartas volteadas por ronda
var carta1=0;        //Variable que guarda la primera carta de cada 2 que volteo
var carta2=0;		  //Variable que guarda la segunda carta de cada 2 que volteo
var aciertos=0;       //Variable para controla el numero de aciertos, a 6 se acaba la partida
var array_aciertos=[]; //Array donde guardamos los aciertos
function voltear(micartaelegida)
{
		//Miro si la nueva carta está en el array de aciertos y asi no contablizarlo
		if(array_aciertos.indexOf(micartaelegida)==-1)
		{
			//no lo ha encontrado y puede continuar
			document.getElementById("foto"+micartaelegida).src="imagenes/"+elegidas[micartaelegida-1];
			if (Cartasvueltas==0)
			{
				//guarda la primera carta
				carta1=micartaelegida;
			}
			else
			{
				//guarda la segunda carta
				carta2=micartaelegida;
			}
			if (carta1!=carta2) //si las cartas son diferentes la suma a la cuenta de volteadas
			{
				Cartasvueltas=Cartasvueltas+1;
			}
		}
}
function iniciar()
{
	elegidas=["p1.jpg","p1.jpg","p3.jpg","p4.jpg","p5.jpg","p6.jpg","p2.jpg","p2.jpg","p3.jpg","p4.jpg","p5.jpg","p6.jpg"];
	//Le damos la vuelta a todas las cartas
	for(a=1;a<=12;a++)
	{
		document.getElementById("foto"+a).src="imagenes/reverso.jpg";
	}
	//Removemos todo el array para mezclarlo y que sea al azar
	elegidas = elegidas.sort(function() {return Math.random() - 0.5});
	//Ocultamos el cuadro de incio de partida
	document.getElementById("caja_de_inicio").className="ocultar";
	//Mostramos el tablero
	document.getElementById("caja_de_juego").className="mostrar";
	//Inicio variables
	Cartasvueltas=0;  
	carta1=0;        
	carta2=0;		 
	aciertos=0;      
	array_aciertos=[];
}
function trasera(micartaelegida)
{
	if (Cartasvueltas==2)
	{//analizar si son iguales o no}
		//if(document.getElementById("foto"+carta1).src==document.getElementById("foto"+carta2).src)
		if(elegidas[carta1-1]==elegidas[carta2-1])
		{
			//las fotos son iguales
			Cartasvueltas=0;
			aciertos++
			//guardo en el array de aciertos
			array_aciertos.push(carta1,carta2);
			if (aciertos==6)
			{
				//Se acabo la partida
				document.getElementById("caja_de_inicio").className="mostrar";
				document.getElementById("mensaje").innerHTML="Felicidades, has acabado la partida";
				document.getElementById("caja_de_juego").className="ocultar";
			}
		}
		else
		{
			//las fotos son diferentes
			Cartasvueltas=0;
			document.getElementById("foto"+carta1).src="imagenes/reverso.jpg";
			document.getElementById("foto"+carta2).src="imagenes/reverso.jpg";
		}
	}

}