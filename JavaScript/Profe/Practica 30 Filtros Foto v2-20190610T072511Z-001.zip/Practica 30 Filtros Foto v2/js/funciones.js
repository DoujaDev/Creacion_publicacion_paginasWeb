var filtro_marcado;
var reloj;
function activa_oscuro(objeto)
{
	objeto.className="oscuro";
}
function activa_claro(objeto)
{
	objeto.className="claro";
}
function filtro(filtro_marca)
{
	
	filtro_marcado=filtro_marca;
	y=0;
	i=100;
	reloj=setInterval("filtro_aplicar()",5);
	
}
function filtro_aplicar()
{
	if(i>0)
	{
			for (var a=0;a<document.getElementsByName("caja_foto").length;a++)
			{
				var clase_actual=document.getElementsByName("caja_foto")[a].className.split(" ");
				if(clase_actual[0]==filtro_marcado || filtro_marcado=="todos")
				{
					foto=document.getElementsByName("foto")[a];
					//mostrar la caja
					foto.style.width= y+"%";
					foto.style.left= (100-y)/2+"%";
					foto.style.top= (100-y)/2+"%";
					foto.style.opacity= y/100;
					document.getElementsByName("caja_foto")[a].className=clase_actual[0]+" mostrar";
				}
				else
				{
					//ocultar la caja
					
					document.getElementsByName("caja_foto")[a].className=clase_actual[0]+" ocultar";
				}
			}
	}
	else
	{
		//Para timer
		clearInterval(reloj);
	}
	i--;
	y++;
}
